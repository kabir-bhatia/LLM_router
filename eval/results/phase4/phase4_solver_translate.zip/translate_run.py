"""Phase 4 D13: local models TRANSLATE dev math/logic tasks into an expression / JSON spec. Python solves offline.
Temperature 0. Output: JSONL, one reply per line. Resumable."""
import argparse, json, os, shutil, subprocess, sys, time, urllib.request

HOST = "http://127.0.0.1:11434"
SYSTEM = json.load(open("translate_prompts.json", encoding="utf-8"))
NUM_PREDICT = {"math": 256, "logic": 800}


def sh(cmd):
    subprocess.run(cmd, shell=True, check=True)


def install_and_serve():
    if not shutil.which("ollama"):
        sh("apt-get update -qq && apt-get install -y -qq zstd >/dev/null 2>&1 || true")
        sh("curl -fsSL https://ollama.com/install.sh | sh")
    try:
        urllib.request.urlopen(HOST + "/api/version", timeout=2)
        return
    except Exception:
        pass
    subprocess.Popen(["ollama", "serve"], stdout=open("/tmp/ollama.log", "w"), stderr=subprocess.STDOUT)
    for _ in range(60):
        try:
            urllib.request.urlopen(HOST + "/api/version", timeout=2)
            return
        except Exception:
            time.sleep(1)
    sys.exit("ollama server did not start; see /tmp/ollama.log")


def chat(model, category, text):
    label = "Problem: " if category == "math" else "Puzzle: "
    payload = {"model": model, "stream": False, "keep_alive": "10m",
               "messages": [{"role": "system", "content": SYSTEM[category]},
                            {"role": "user", "content": label + text}],
               "options": {"temperature": 0, "num_predict": NUM_PREDICT[category], "num_ctx": 4096}}
    if category == "logic":
        payload["format"] = "json"
    if model.startswith("qwen3"):
        payload["think"] = False
    req = urllib.request.Request(HOST + "/api/chat", json.dumps(payload).encode(), {"Content-Type": "application/json"})
    t0 = time.perf_counter()
    with urllib.request.urlopen(req, timeout=600) as r:
        d = json.load(r)
    return d, int((time.perf_counter() - t0) * 1000)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", default="tasks_translate.json")
    ap.add_argument("--models", nargs="+", required=True)
    ap.add_argument("--out", default="translations.jsonl")
    a = ap.parse_args()
    tasks = json.load(open(a.tasks, encoding="utf-8"))
    install_and_serve()
    done = set()
    if os.path.exists(a.out):
        for line in open(a.out, encoding="utf-8"):
            if line.strip():
                r = json.loads(line)
                done.add((r["model"], r["task_id"]))
    for model in a.models:
        sh("ollama pull " + model)
        n = 0
        for t in tasks:
            if (model, t["id"]) in done:
                continue
            rec = {"task_id": t["id"], "model": model, "category": t["category"], "raw_text": "", "tokens_out": None,
                   "latency_ms": None, "done_reason": None, "error": None}
            try:
                d, ms = chat(model, t["category"], t["prompt"])
                msg = d.get("message", {})
                rec.update(raw_text=msg.get("content", ""), tokens_out=d.get("eval_count"), latency_ms=ms,
                           done_reason=d.get("done_reason"))
            except Exception as e:
                rec["error"] = str(e)[:300]
            with open(a.out, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n += 1
            if n % 20 == 0:
                print(model, n, "done", flush=True)
        sh("ollama stop " + model + " || true")
        sh("ollama rm " + model)
    print("done ->", a.out)


if __name__ == "__main__":
    main()
